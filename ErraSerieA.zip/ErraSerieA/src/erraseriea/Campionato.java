package erraseriea;
import java.util.Scanner;
import java.io.*;

public class Campionato {
    Scanner scanner = new Scanner(System.in);
    int dim = 20;
    private squadra[] classifica;
    
    public Campionato() throws FileNotFoundException {
        classifica = new squadra[dim];
        File f = new File("Data/serie_a_2025_classifica_intestata.csv");
        Scanner leggi = new Scanner(f);
        
        for(int i = 0; leggi.hasNextLine();i++){
            String s = leggi.nextLine();
            String[] ss = s.split(",");
            String nome = ss[0]; 
            int posizione = Integer.parseInt(ss[1]);
            int vinte = Integer.parseInt(ss[2]);
            int pareggiate = Integer.parseInt(ss[3]);
            int perse = Integer.parseInt(ss[4]);
            int punteggio = Integer.parseInt(ss[5]);
            
            classifica[i]= new squadra(nome, posizione, vinte, pareggiate, perse, punteggio);
        }
        
        leggi.close();
    }
    
    public void stampaCampionato(){
        for(int i = 0; i<20; i++){
            System.out.println(classifica[i].getPosizione()+""+ classifica[i].getNome());
        }
    }
    
}
