package erraseriea;

class squadra {

    String Nome;
    int Posizione, Vinte, Pareggiate, Perse, Punteggio;

    public squadra(String Nome, int Posizione, int Vinte, int Pareggiate, int Perse, int Punteggio) {
        this.Nome = Nome;
        this.Posizione = Posizione;
        this.Vinte = Vinte;
        this.Pareggiate = Pareggiate;
        this.Perse = Perse;
        this.Punteggio = Punteggio;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public int getPosizione() {
        return Posizione;
    }

    public void setPosizione(int Posizione) {
        this.Posizione = Posizione;
    }

    public int getVinte() {
        return Vinte;
    }

    public void setVinte(int Vinte) {
        this.Vinte = Vinte;
    }

    public int getPareggiate() {
        return Pareggiate;
    }

    public void setPareggiate(int Pareggiate) {
        this.Pareggiate = Pareggiate;
    }

    public int getPerse() {
        return Perse;
    }

    public void setPerse(int Perse) {
        this.Perse = Perse;
    }

    public int getPunteggio() {
        return Punteggio;
    }

    public void setPunteggio(int Punteggio) {
        this.Punteggio = Punteggio;
    }
    
    
    
}
