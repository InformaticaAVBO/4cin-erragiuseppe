package erraseriea;

import java.io.FileNotFoundException;

public class ErraSerieA {

    public static void main(String[] args) throws FileNotFoundException {
    Campionato seriea = new Campionato();
    seriea.stampaCampionato();
    }
    
}
